print('Hello! My name is Griffin')
name = input('What is your name?')
print ('Hello ' + name + ', nice to meet you')